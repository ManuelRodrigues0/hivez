import { useState } from "react";
import {
  doc,
  getDoc,
  setDoc,
} from "firebase/firestore";
import { db } from "../../firebase/firebase";
import { useAuth } from "../../context/AuthContext";

export default function CompleteProfile() {
  const { user, refreshProfileStatus } = useAuth();

  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [loading, setLoading] = useState(false);

  async function saveProfile() {
    if (!user) return;

    const rawUsername = username.trim();
    // Strip @ if user typed it in the username field
    const cleanUsername = rawUsername.replace(/^@+/, "").toLowerCase();

    if (cleanUsername.length < 3) {
      alert("Username must be at least 3 characters.");
      return;
    }

    setLoading(true);

    const usernameDoc = await getDoc(
      doc(db, "usernames", cleanUsername)
    );

    if (usernameDoc.exists()) {
      alert("Username already taken.");
      setLoading(false);
      return;
    }

    try {
      await setDoc(
        doc(db, "users", user.uid),
        {
          username: cleanUsername,
          bio,
          profileCompleted: true,
        },
        { merge: true }
      );

      await setDoc(
        doc(db, "usernames", cleanUsername),
        {
          uid: user.uid,
        }
      );

      await refreshProfileStatus();
    } catch (err: any) {
      alert(err.message || "Failed to save profile.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black text-zinc-900 dark:text-white flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <h1 className="mb-8 text-center text-4xl font-bold text-zinc-900 dark:text-white">
          Complete Profile
        </h1>

        <input
          className="mb-4 w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 p-4 text-zinc-900 dark:text-white"
          placeholder="Username"
          value={username}
          onChange={(e) =>
            setUsername(e.target.value)
          }
        />

        <textarea
          className="mb-6 h-28 w-full resize-none rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 p-4 text-zinc-900 dark:text-white"
          placeholder="Bio"
          value={bio}
          onChange={(e) =>
            setBio(e.target.value)
          }
        />

        <button
          onClick={saveProfile}
          disabled={loading}
          className="w-full rounded-xl bg-zinc-900 dark:bg-white p-4 font-semibold text-white dark:text-black transition hover:bg-zinc-800 dark:hover:bg-zinc-200 disabled:opacity-50"
        >
          {loading ? "Saving..." : "Continue"}
        </button>
      </div>
    </div>
  );
}