import { useEffect, useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import {
  CalendarDays,
  CheckCircle2,
  Loader2,
  MapPin,
  Send,
  ShieldCheck,
  Trash2,
  Upload,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import HivezLoader from "@/components/common/HivezLoader";
import EvidenceGallery from "@/components/volunteering/EvidenceGallery";
import MediaViewer, { detectMediaType } from "@/components/volunteering/MediaViewer";
import { useAuth } from "@/context/AuthContext";
import { useLiveUserSummary } from "@/hooks/useLiveProfile";
import { uploadToCloudinary } from "@/services/mediaUpload";
import {
  closePoll,
  createPoll,
  createVolunteerActivity,
  deletePoll,
  joinActivity,
  leaveActivity,
  listenActivityEvidence,
  listenActivityParticipant,
  listenCommunityMember,
  listenCommunityMembers,
  listenCommunityMessages,
  listenCommunityPolls,
  listenIssueCommunity,
  listenVolunteerActivities,
  removeCommunityMember,
  reopenPoll,
  reviewActivityEvidence,
  sendCommunityMessage,
  submitActivityEvidence,
  updateActivityDetails,
  updateActivityStatus,
  updateCommunityMemberRole,
  updateCommunityStatus,
  addActivityTask,
  assignParticipantRole,
  listenActivityParticipants,
  logContactUpdate,
  removeActivityTask,
  setParticipantStatus,
  toggleActivityTask,
  updateActionProgress,
  votePoll,
} from "@/services/volunteering";
import VerificationPanel from "./VerificationPanel";
import {
  ACTION_TYPE_GROUPS,
  ACTION_TYPES,
  actionTypeSummary,
  createActionLabel,
  getActionFormConfig,
  getActionType,
  progressStateLabel,
  suggestedActionTypes,
} from "@/utils/actionTypes";

import type {
  ActionProgressState,
  ActionTypeKey,
  ActivityEvidence,
  ActivityParticipant,
  CommunityMember,
  CommunityMessage,
  CommunityPoll,
  EvidenceTypeKey,
  IssueCommunity,
  IssueCommunityStatus,
  ParticipantStatus,
  PollVote,
  VolunteerActivity,
  VolunteerActivityStatus,
  VolunteerUserSummary,
} from "@/types/volunteering";

const tabs = ["Discussion", "Chat", "Polls", "Actions", "Progress", "Members", "Evidence", "Verification"] as const;
type Tab = (typeof tabs)[number];

const issueStatuses: IssueCommunityStatus[] = [
  "REPORTED",
  "COMMUNITY_VERIFIED",
  "ACTION_STARTED",
  "IN_PROGRESS",
  "AWAITING_VERIFICATION",
  "RESOLVED",
  "VERIFIED",
  "ARCHIVED",
];

const activityStatuses: VolunteerActivityStatus[] = ["OPEN", "ACTIVE", "AWAITING_VERIFICATION", "VERIFIED", "COMPLETED", "CANCELLED"];

function pretty(value: string) {
  return value.replaceAll("_", " ").toLowerCase();
}

function timeText(value: { toDate?: () => Date } | null | undefined) {
  if (!value?.toDate) return "";
  return value.toDate().toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function IssueCommunityPage() {
  const { communityId } = useParams();
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  // Live user summary (replaces one-time getUserSummary read).
  const summary = useLiveUserSummary(user?.uid);
  const [community, setCommunity] = useState<IssueCommunity | null>(null);
  const [member, setMember] = useState<CommunityMember | null>(null);
  const [members, setMembers] = useState<CommunityMember[]>([]);
  const [discussion, setDiscussion] = useState<CommunityMessage[]>([]);
  const [chat, setChat] = useState<CommunityMessage[]>([]);
  const [polls, setPolls] = useState<Array<CommunityPoll & { myVote?: PollVote }>>([]);
  const [activities, setActivities] = useState<VolunteerActivity[]>([]);
  const [evidence, setEvidence] = useState<ActivityEvidence[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>(() =>
    searchParams.get("tab") === "Verification" ? "Verification" : "Discussion"
  );
  const [messageText, setMessageText] = useState("");
  const [pollQuestion, setPollQuestion] = useState("");
  const [pollOptions, setPollOptions] = useState("Yes\nNo");
  const [activityTitle, setActivityTitle] = useState("");
  const [activityDescription, setActivityDescription] = useState("");
  const [activityDate, setActivityDate] = useState("");
  const [activityTime, setActivityTime] = useState("");
  const [activityLocation, setActivityLocation] = useState("");
  const [activityLimit, setActivityLimit] = useState("10");
  const [activityRoles, setActivityRoles] = useState("Volunteer, Organizer");
  const [actionType, setActionType] = useState<ActionTypeKey | null>(null);
  const [typeFieldValues, setTypeFieldValues] = useState<Record<string, string>>({});
  const suggestedTypes = useMemo(() => suggestedActionTypes(community?.category), [community?.category]);
  const selectedTypeMeta = actionType ? getActionType(actionType) : null;
  const formConfig = getActionFormConfig(actionType);
  const [creatingAction, setCreatingAction] = useState(false);
  const [pickedEvidenceActivityId, setPickedEvidenceActivityId] = useState<string | null>(null);
  const [evidenceDescription, setEvidenceDescription] = useState("");
  const [evidenceUrl, setEvidenceUrl] = useState("");
  const [evidenceKind, setEvidenceKind] = useState<EvidenceTypeKey>("AFTER");
  const [beforeEvidenceUrl, setBeforeEvidenceUrl] = useState("");
  const [evidenceUploading, setEvidenceUploading] = useState(false);
  const [evidenceSubmitting, setEvidenceSubmitting] = useState(false);
  const [headerViewerOpen, setHeaderViewerOpen] = useState(false);
  const [participants, setParticipants] = useState<ActivityParticipant[]>([]);
  const [selectedParticipantId, setSelectedParticipantId] = useState<string | null>(null);
  const [newTaskLabel, setNewTaskLabel] = useState("");
  const [contactOrg, setContactOrg] = useState("");
  const [contactMethod, setContactMethod] = useState("");
  const [contactResult, setContactResult] = useState("");
  const [contactNextFollowup, setContactNextFollowup] = useState("");
  const [contactNotes, setContactNotes] = useState("");
  const [expandedActionId, setExpandedActionId] = useState<string | null>(null);

  useEffect(() => {
    if (!communityId) return;
    return listenIssueCommunity(communityId, setCommunity);
  }, [communityId]);

  useEffect(() => {
    if (!communityId || !user) return;
    return listenCommunityMember(communityId, user.uid, setMember);
  }, [communityId, user]);

  useEffect(() => {
    if (!communityId) return;
    const unsubs = [
      listenCommunityMembers(communityId, setMembers),
      listenCommunityMessages(communityId, "discussion", setDiscussion),
      listenCommunityMessages(communityId, "chat", setChat),
      listenCommunityPolls(communityId, user?.uid, setPolls),
      listenVolunteerActivities(communityId, setActivities),
      listenActivityEvidence(communityId, setEvidence),
    ];
    return () => unsubs.forEach((unsubscribe) => unsubscribe());
  }, [communityId, user?.uid]);

  const canManage = member?.role === "owner" || member?.role === "organizer" || member?.role === "moderator";
  const isOwner = member?.role === "owner";
  const isMember = Boolean(member);

  // Derived: the first live action preselects the evidence target until the
  // user explicitly picks one — no sync-in-effect state copy needed.
  const evidenceActivityId = pickedEvidenceActivityId ?? activities[0]?.id ?? "";

  // Live participant list for the currently-expanded action.
  useEffect(() => {
    if (!expandedActionId) return undefined;
    return listenActivityParticipants(expandedActionId, setParticipants);
  }, [expandedActionId]);

  async function handleSendMessage(event: FormEvent) {
    event.preventDefault();
    if (!communityId || !summary || !messageText.trim() || !isMember) return;
    await sendCommunityMessage({
      communityId,
      user: summary,
      text: messageText,
      kind: activeTab === "Chat" ? "chat" : "discussion",
    });
    setMessageText("");
  }

  async function handleCreatePoll(event: FormEvent) {
    event.preventDefault();
    if (!communityId || !user || !canManage || !pollQuestion.trim()) return;
    const options = pollOptions.split(/\n|,/).map((item) => item.trim()).filter(Boolean).slice(0, 6);
    if (options.length < 2) return toast.error("Add at least two options");
    await createPoll({ communityId, question: pollQuestion, options, createdBy: user.uid });
    setPollQuestion("");
    setPollOptions("Yes\nNo");
    toast.success("Poll created");
  }

  function chooseActionType(key: ActionTypeKey) {
    const meta = getActionType(key);
    setTypeFieldValues({});
    setActivityRoles(meta?.defaultRoles?.join(", ") || "Volunteer");
    setActionType(key);
  }

  async function handleCreateActivity(event: FormEvent) {
    event.preventDefault();
    if (creatingAction) return;
    if (!community || !summary || !canManage || !actionType || !activityTitle.trim()) return;
    const meta = getActionType(actionType);
    const config = getActionFormConfig(actionType);
    const typeDetails: Record<string, string> = {};
    config.fields.forEach((field) => {
      const value = typeFieldValues[field.key]?.trim();
      if (value) typeDetails[field.key] = value;
    });
    setCreatingAction(true);
    try {
      await createVolunteerActivity({
        communityId: community.id,
        issueId: community.issueId,
        title: activityTitle,
        description: activityDescription,
        category: community.category,
        organizerId: summary.uid,
        organizer: summary,
        location: config.meeting ? activityLocation || community.location || "" : "",
        meetingPoint: config.meeting ? activityLocation || community.location || "" : "",
        startDate: config.schedule ? activityDate : "",
        startTime: config.schedule ? activityTime : "",
        endDate: config.schedule ? activityDate : "",
        endTime: "",
        volunteerLimit: config.capacity ? Number(activityLimit) || 0 : 0,
        status: "OPEN",
        urgent: false,
        actionType,
        actionKind: meta?.kind || null,
        typeDetails: Object.keys(typeDetails).length > 0 ? typeDetails : null,
        roles: config.roles
          ? activityRoles.split(",").map((item) => item.trim()).filter(Boolean)
          : meta?.defaultRoles?.length
            ? meta.defaultRoles
            : ["Volunteer"],
        requirements: config.meeting ? "Bring what you need for the activity." : "",
        instructions:
          meta?.kind === "external"
            ? "An external party performs this work - volunteers coordinate and track progress safely."
            : "Coordinate in the community chat before arriving.",
        verificationMethod: "Organizer review",
        evidenceRequirements: "Upload a photo, video, or short note after the work is done.",
      });
      setActivityTitle("");
      setActivityDescription("");
      setActivityDate("");
      setActivityTime("");
      setActivityLocation("");
      setActivityLimit("10");
      setTypeFieldValues({});
      setActionType(null);
      toast.success("Volunteer action created");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create the action. Please try again.");
    } finally {
      setCreatingAction(false);
    }
  }

  async function uploadEvidenceFile(file: File) {
    if (evidenceUploading) return null;
    const isVideo = file.type.startsWith("video");
    const isImage = file.type.startsWith("image");
    if (!isVideo && !isImage) {
      toast.error("Please choose an image or video file.");
      return null;
    }
    if (file.size > 15 * 1024 * 1024) {
      toast.error("That file is larger than 15 MB. Please choose a smaller file.");
      return null;
    }
    setEvidenceUploading(true);
    try {
      const result = await uploadToCloudinary(file);
      return { url: result.secure_url, mediaType: (result.resource_type === "video" ? "video" : "image") as "image" | "video" };
    } catch {
      toast.error("Upload failed. Check your connection and try again.");
      return null;
    } finally {
      setEvidenceUploading(false);
    }
  }

  async function handleEvidenceFile(event: React.ChangeEvent<HTMLInputElement>, target: "main" | "before") {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    const uploaded = await uploadEvidenceFile(file);
    if (!uploaded) return;
    const url = uploaded.url;
    if (target === "before") setBeforeEvidenceUrl(url);
    else setEvidenceUrl(url);
    toast.success("Upload complete");
  }

  async function handleSubmitEvidence(event: FormEvent) {
    event.preventDefault();
    if (!community || !summary || !evidenceActivityId || evidenceSubmitting || evidenceUploading) return;
    const description = evidenceDescription.trim();
    if (!description && !evidenceUrl && !beforeEvidenceUrl) {
      toast.error("Add a short description or media before submitting.");
      return;
    }
    setEvidenceSubmitting(true);
    const mediaUrl = evidenceUrl || undefined;
    const beforeUrl = beforeEvidenceUrl || undefined;
    const mediaType = detectMediaType(mediaUrl || beforeUrl, undefined);
    try {
      await submitActivityEvidence({
        activityId: evidenceActivityId,
        communityId: community.id,
        uid: summary.uid,
        user: summary,
        description,
        kind: toVerificationKind(evidenceKind),
        evidenceType: evidenceKind === "BEFORE" ? "BEFORE" : evidenceKind === "AFTER" ? "AFTER" : "REPORT",
        mediaUrl,
        beforeMediaUrl: evidenceKind === "BEFORE" ? beforeUrl || mediaUrl || null : null,
        afterMediaUrl: evidenceKind === "AFTER" ? mediaUrl || null : null,
        mediaType,
      });
      setEvidenceDescription("");
      setEvidenceUrl("");
      setBeforeEvidenceUrl("");
      toast.success("Evidence submitted for review");
    } catch (error) {
      console.error(error);
      toast.error("Could not submit evidence");
    } finally {
      setEvidenceSubmitting(false);
    }
  }

  if (!communityId || !community) {
    return (
      <div className="app-page">
        <div className="app-empty-state">
          <HivezLoader size="md" progress={58} label="Loading issue community" />
        </div>
      </div>
    );
  }

  return (
    <div className="app-page">
      <header className="border-b border-zinc-200 bg-white dark:border-zinc-800 dark:bg-black">
        <div className="px-4 py-3 sm:py-4">
          <div className="mb-2 flex flex-wrap items-center gap-2 sm:mb-3">
            <span className="rounded-full bg-zinc-950 px-2.5 py-0.5 text-[11px] font-bold uppercase text-white dark:bg-white dark:text-black sm:px-3 sm:py-1 sm:text-xs">{pretty(community.status)}</span>
            {community.location && <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] font-bold text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300 sm:px-3 sm:py-1 sm:text-xs"><MapPin size={12} />{community.location}</span>}
            <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] font-bold text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300 sm:px-3 sm:py-1 sm:text-xs"><Users size={12} />{community.memberCount} members</span>
          </div>
          <div className="flex items-start gap-2.5 sm:gap-3">
            {community.mediaUrl && (
              <button
                onClick={() => setHeaderViewerOpen(true)}
                className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-zinc-100 ring-2 ring-transparent transition hover:ring-zinc-300 dark:bg-zinc-900 dark:hover:ring-zinc-700 sm:h-14 sm:w-14"
                aria-label="Open issue media"
              >
                {community.mediaType === "video" ? (
                  <video src={community.mediaUrl} className="h-full w-full object-cover" muted playsInline disablePictureInPicture />
                ) : (
                  <img src={community.mediaUrl} alt="" className="h-full w-full object-cover" loading="lazy" />
                )}
              </button>
            )}
            <Link to={`/issue-community/${community.id}/details`} className="group block flex-1">
              <h1 className="text-lg font-black tracking-tight text-zinc-950 transition group-hover:underline dark:text-white sm:text-xl sm:font-black md:text-2xl">{community.title}</h1>
            </Link>
          </div>
          <p className="mt-1.5 text-xs leading-5 text-zinc-700 dark:text-zinc-300 sm:mt-2 sm:text-sm sm:leading-6">{community.description}</p>
          <p className="mt-0.5 text-[11px] text-zinc-500 dark:text-zinc-400 sm:mt-1 sm:text-xs">@{community.owner.username}</p>
        </div>
      </header>

      {headerViewerOpen && community.mediaUrl && (
        <MediaViewer
          items={[{ src: community.mediaUrl, mediaType: community.mediaType === "video" ? "video" : "image", alt: community.title, caption: community.title }]}
          index={0}
          onClose={() => setHeaderViewerOpen(false)}
          title={community.title}
        />
      )}

      <nav className="sticky top-0 z-10 flex gap-2 overflow-x-auto border-b border-zinc-200 bg-white/95 px-4 py-3 backdrop-blur-xl dark:border-zinc-800 dark:bg-black/95">
        {tabs.map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`h-10 shrink-0 rounded-full px-4 text-sm font-bold transition ${activeTab === tab ? "bg-zinc-950 text-white dark:bg-white dark:text-black" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800"}`}>
            {tab}
          </button>
        ))}
      </nav>

      <main className="px-4 py-5">
        {(activeTab === "Discussion" || activeTab === "Chat") && (
          <MessagePanel messages={activeTab === "Chat" ? chat : discussion} canPost={isMember} value={messageText} onChange={setMessageText} onSubmit={handleSendMessage} mode={activeTab} />
        )}

        {activeTab === "Polls" && (
          <section className="space-y-4">
            {canManage && (
              <form onSubmit={handleCreatePoll} className="space-y-3 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                <input value={pollQuestion} onChange={(e) => setPollQuestion(e.target.value)} placeholder="Ask the community" className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                <textarea value={pollOptions} onChange={(e) => setPollOptions(e.target.value)} className="min-h-24 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                <button className="h-10 rounded-full bg-zinc-950 px-5 text-sm font-bold text-white dark:bg-white dark:text-black">Create poll</button>
              </form>
            )}
            {polls.map((poll) => (
              <div key={poll.id} className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-950">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-black text-zinc-950 dark:text-white">{poll.question}</h3>
                  {canManage && (
                    <div className="flex items-center gap-2">
                      {poll.status === "OPEN" ? (
                        <button onClick={() => closePoll(poll.id)} className="text-xs font-bold text-zinc-500 hover:text-zinc-950 dark:hover:text-white">Close</button>
                      ) : (
                        <button onClick={() => reopenPoll(poll.id)} className="text-xs font-bold text-zinc-500 hover:text-zinc-950 dark:hover:text-white">Reopen</button>
                      )}
                      {isOwner && <button onClick={() => deletePoll(poll.id)} className="text-red-500 hover:text-red-400"><Trash2 size={15} /></button>}
                    </div>
                  )}
                </div>
                <div className="mt-4 space-y-2">
                  {poll.options.map((option, index) => {
                    const count = poll.counts[index] || 0;
                    const percent = poll.totalVotes ? Math.round((count / poll.totalVotes) * 100) : 0;
                    const selected = poll.myVote?.optionIndex === index;
                    return (
                      <button key={option} disabled={!isMember || Boolean(poll.myVote) || poll.status !== "OPEN"} onClick={() => user && votePoll(poll, user.uid, index).then(() => toast.success("Vote recorded"))} className={`relative h-11 w-full overflow-hidden rounded-xl border px-4 text-left text-sm font-bold disabled:cursor-default ${selected ? "border-emerald-400" : "border-zinc-200 dark:border-zinc-800"}`}>
                        <span className={`absolute inset-y-0 left-0 ${selected ? "bg-emerald-100 dark:bg-emerald-950" : "bg-zinc-100 dark:bg-zinc-900"}`} style={{ width: `${percent}%` }} />
                        <span className="relative flex justify-between"><span>{option}</span><span>{percent}%</span></span>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-3 text-xs font-semibold text-zinc-500">{poll.totalVotes} votes • {pretty(poll.status)}</p>
              </div>
            ))}
            {!polls.length && <EmptyBlock text="No polls yet. Owners and organizers can create one above." />}
          </section>
        )}

        {activeTab === "Actions" && (
          <section className="space-y-4">
            {canManage && (
              <>
                {!actionType ? (
                  <div className="space-y-4 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                    <div>
                      <p className="text-base font-black text-zinc-950 dark:text-white">What should we do?</p>
                      <p className="text-xs font-semibold text-zinc-500">Choose an action for this issue. Each action has its own focused workflow.</p>
                    </div>
                    {suggestedTypes.length > 0 && (
                      <div>
                        <p className="mb-2 text-[11px] font-black uppercase tracking-wide text-emerald-600 dark:text-emerald-400">Suggested for this issue</p>
                        <div className="grid gap-1.5 sm:grid-cols-2">
                          {suggestedTypes.map((meta) => (
                            <button
                              key={meta.key}
                              type="button"
                              onClick={() => chooseActionType(meta.key)}
                              title={meta.description}
                              className="flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-left text-sm font-bold text-emerald-800 transition hover:border-emerald-400 dark:border-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-200"
                            >
                              <span className="text-lg">{meta.emoji}</span>
                              <span className="min-w-0 flex-1 truncate">{meta.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="space-y-3">
                      <p className="text-[11px] font-black uppercase tracking-wide text-zinc-500">All action types</p>
                      {ACTION_TYPE_GROUPS.map((group) => {
                        const options = ACTION_TYPES.filter((meta) => group.keys.includes(meta.key) && !suggestedTypes.some((s) => s.key === meta.key));
                        if (!options.length) return null;
                        return (
                          <div key={group.label}>
                            <p className="mb-1.5 text-[11px] font-bold text-zinc-400">{group.label}</p>
                            <div className="grid gap-1.5 sm:grid-cols-2">
                              {options.map((meta) => (
                                <button
                                  key={meta.key}
                                  type="button"
                                  onClick={() => chooseActionType(meta.key)}
                                  title={meta.description}
                                  className="flex items-center gap-2 rounded-2xl border border-zinc-200 px-3 py-2.5 text-left text-sm font-bold text-zinc-700 transition hover:border-zinc-400 dark:border-zinc-800 dark:text-zinc-300"
                                >
                                  <span className="text-lg">{meta.emoji}</span>
                                  <span className="min-w-0 flex-1 truncate">{meta.label}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleCreateActivity} className="space-y-3 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex min-w-0 items-start gap-2">
                        <span className="text-xl">{selectedTypeMeta?.emoji}</span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-black text-zinc-950 dark:text-white">{selectedTypeMeta?.label}</p>
                          <p className="line-clamp-2 text-[11px] font-semibold leading-4 text-zinc-500">{selectedTypeMeta?.description}</p>
                        </div>
                      </div>
                      <button type="button" onClick={() => setActionType(null)} className="shrink-0 rounded-full border border-zinc-200 px-3 py-1.5 text-[11px] font-bold text-zinc-600 hover:border-zinc-400 dark:border-zinc-800 dark:text-zinc-300">← Change</button>
                    </div>
                    <input value={activityTitle} onChange={(e) => setActivityTitle(e.target.value)} placeholder="Action title" className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                    <textarea value={activityDescription} onChange={(e) => setActivityDescription(e.target.value)} placeholder="What needs to happen?" className="min-h-20 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                {formConfig.schedule && (
                      <div className="grid gap-3 sm:grid-cols-2">
                        <input type="date" value={activityDate} onChange={(e) => setActivityDate(e.target.value)} className="h-12 rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                        <input type="time" value={activityTime} onChange={(e) => setActivityTime(e.target.value)} className="h-12 rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      </div>
                    )}
                    {formConfig.meeting && (
                      <input value={activityLocation} onChange={(e) => setActivityLocation(e.target.value)} placeholder="Location / meeting point" className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                    )}
                    {formConfig.capacity && (
                      <input value={activityLimit} onChange={(e) => setActivityLimit(e.target.value)} placeholder="Volunteer limit" className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                    )}
                    {formConfig.roles && (
                      <input value={activityRoles} onChange={(e) => setActivityRoles(e.target.value)} placeholder="Roles (comma separated)" className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                    )}

                    {formConfig.fields.map((field) => {
                      const value = typeFieldValues[field.key] || "";
                      const setValue = (next: string) => setTypeFieldValues((prev) => ({ ...prev, [field.key]: next }));
                      const fieldClass = "h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white";
                      if (field.kind === "textarea") {
                        return (
                          <textarea key={field.key} value={value} onChange={(e) => setValue(e.target.value)} placeholder={field.label} className="min-h-20 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                        );
                      }
                      if (field.kind === "select") {
                        return (
                          <select key={field.key} value={value} onChange={(e) => setValue(e.target.value)} className={fieldClass}>
                            <option value="">{field.label}…</option>
                            {field.options?.map((option) => (
                              <option key={option} value={option}>{option}</option>
                            ))}
                          </select>
                        );
                      }
                      return (
                        <input
                          key={field.key}
                          type={field.kind === "number" ? "number" : field.kind === "date" ? "date" : field.kind === "time" ? "time" : "text"}
                          value={value}
                          onChange={(e) => setValue(e.target.value)}
                          placeholder={field.label}
                          className={fieldClass}
                        />
                      );
                    })}

                    <button disabled={!activityTitle.trim() || creatingAction} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-full bg-zinc-950 text-sm font-bold text-white disabled:opacity-50 dark:bg-white dark:text-black">
                      {creatingAction ? (<><Loader2 size={15} className="animate-spin" /> Creating…</>) : createActionLabel(actionType)}
                    </button>
                  </form>
                )}
              </>
            )}
            {activities.map((activity) => (
              <div key={activity.id} className="space-y-2">
                <ActivityCard
                  activity={activity}
                  summary={summary}
                  canManage={canManage}
                  isOwner={isOwner}
                  isCommunityMember={isMember}
                  expanded={expandedActionId === activity.id}
                  onToggleExpand={() => { setParticipants([]); setExpandedActionId(expandedActionId === activity.id ? null : activity.id); }}
                />
                {expandedActionId === activity.id && canManage && (
                  <section className="rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                    <p className="text-sm font-black text-zinc-950 dark:text-white">Manage {activity.title}</p>

                    <p className="mt-3 text-xs font-black uppercase tracking-wide text-zinc-500">
                      Participants · {activity.volunteerCount}{activity.volunteerLimit ? `/${activity.volunteerLimit}` : ""}
                    </p>
                    <div className="mt-2 space-y-2">
                      {participants.map((p) => (
                        <div
                          key={p.id}
                          onClick={() => setSelectedParticipantId(selectedParticipantId === p.id ? null : p.id)}
                          className={`flex flex-wrap items-center gap-2 rounded-2xl border p-2 ${selectedParticipantId === p.id ? "border-emerald-400 ring-2 ring-emerald-400/30" : "border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900"}`}
                        >
                          <img src={p.user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(p.user.displayName)}&background=111&color=fff`} alt="" className="h-8 w-8 rounded-full object-cover" />
                          <span className="min-w-0 flex-1 truncate text-sm font-bold text-zinc-900 dark:text-white">{p.user.displayName}</span>
                          <select
                            value={p.role}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => assignParticipantRole({ participant: p, activity, role: e.target.value, manager: summary! })
                              .then(() => toast.success("Role updated"))
                              .catch((err) => toast.error(err.message))}
                            className="h-9 rounded-full border border-zinc-200 bg-white px-3 text-xs font-bold dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                          >
                            {(activity.roles.length ? activity.roles : ["Volunteer"]).map((role) => <option key={role} value={role}>{role}</option>)}
                          </select>
                          <select
                            value={p.participantStatus || "JOINED"}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => setParticipantStatus({ participant: p, activity, status: e.target.value as ParticipantStatus, manager: summary! })
                              .then(() => toast.success("Status updated"))
                              .catch((err) => toast.error(err.message))}
                            className="h-9 rounded-full border border-zinc-200 bg-white px-3 text-xs font-bold capitalize dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                          >
                            {(["JOINED", "CONFIRMED", "COMPLETED", "WITHDREW"] as const).map((s) => <option key={s} value={s}>{s.toLowerCase()}</option>)}
                          </select>
                        </div>
                      ))}
                      {!participants.length && <p className="text-xs font-semibold text-zinc-500">No one has joined this action yet.</p>}
                    </div>

                    <p className="mt-4 text-xs font-black uppercase tracking-wide text-zinc-500">Checklist</p>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newTaskLabel.trim()) return;
                        addActivityTask({ activity, label: newTaskLabel })
                          .then(() => { setNewTaskLabel(""); toast.success("Task added"); })
                          .catch((err) => toast.error(err.message));
                      }}
                      className="mt-2 flex gap-2"
                    >
                      <input value={newTaskLabel} onChange={(e) => setNewTaskLabel(e.target.value)} placeholder="Add a task…" className="h-10 min-w-0 flex-1 rounded-full border border-zinc-200 bg-zinc-50 px-4 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      <button className="h-10 shrink-0 rounded-full bg-zinc-950 px-4 text-xs font-bold text-white dark:bg-white dark:text-black">Add</button>
                    </form>
                    {activity.tasks?.map((task, index) => (
                      <button
                        key={task.id}
                        onClick={() => toggleActivityTask({ activity, index }).catch((err) => toast.error(err.message))}
                        className={`mt-2 flex w-full items-center gap-2 rounded-2xl border px-3 py-2 text-left text-sm font-semibold ${task.done ? "border-emerald-300 text-zinc-400 line-through dark:border-emerald-800" : "border-zinc-200 text-zinc-800 dark:border-zinc-800 dark:text-white"}`}
                      >
                        <span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border ${task.done ? "border-emerald-400 bg-emerald-400 text-white" : "border-zinc-300 dark:border-zinc-700"}`}>{task.done && <CheckCircle2 size={13} />}</span>
                        <span className="min-w-0 flex-1">{task.label}</span>
                        <span onClick={(e) => { e.stopPropagation(); removeActivityTask({ activity, index }).catch((err) => toast.error(err.message)); }} className="text-red-500"><Trash2 size={14} /></span>
                      </button>
                    ))}
                    {!activity.tasks?.length && <p className="mt-2 text-xs font-semibold text-zinc-500">No tasks yet.</p>}

                    <p className="mt-4 text-xs font-black uppercase tracking-wide text-zinc-500">Contact & follow-up log</p>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!summary) return;
                        logContactUpdate({
                          activity,
                          user: summary,
                          contactedOrg: contactOrg,
                          method: contactMethod,
                          result: contactResult,
                          nextFollowUp: contactNextFollowup,
                          notes: contactNotes,
                        })
                          .then(() => {
                            setContactOrg("");
                            setContactMethod("");
                            setContactResult("");
                            setContactNextFollowup("");
                            setContactNotes("");
                            toast.success("Contact update logged");
                          })
                          .catch((err) => toast.error(err.message));
                      }}
                      className="mt-2 grid gap-2 sm:grid-cols-2"
                    >
                      <input value={contactOrg} onChange={(e) => setContactOrg(e.target.value)} placeholder="Organization / person" className="h-10 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      <input value={contactMethod} onChange={(e) => setContactMethod(e.target.value)} placeholder="Method (call, email…)" className="h-10 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      <input value={contactResult} onChange={(e) => setContactResult(e.target.value)} placeholder="Result / status" className="h-10 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      <input value={contactNextFollowup} onChange={(e) => setContactNextFollowup(e.target.value)} placeholder="Next follow-up date" className="h-10 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                      <input value={contactNotes} onChange={(e) => setContactNotes(e.target.value)} placeholder="Notes" className="h-10 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white sm:col-span-2" />
                      <button className="h-10 rounded-full bg-zinc-950 px-5 text-sm font-bold text-white dark:bg-white dark:text-black sm:col-span-2">Log contact update</button>
                    </form>
                  </section>
                )}
              </div>
            ))}
            {!activities.length && <EmptyBlock text="No volunteer actions yet." />}
          </section>
        )}

        {activeTab === "Progress" && (
          <section className="space-y-4 rounded-3xl border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-zinc-950">
            <div className="flex items-center gap-3">
              <ShieldCheck className="text-emerald-500" />
              <div>
                <h2 className="text-lg font-black text-zinc-950 dark:text-white">Community progress</h2>
                <p className="text-sm text-zinc-500">Track the issue from report to resolution.</p>
              </div>
            </div>
            {canManage && (
              <select value={community.status} onChange={(e) => updateCommunityStatus(community.id, e.target.value as IssueCommunityStatus)} className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm font-bold dark:border-zinc-800 dark:bg-zinc-900 dark:text-white">
                {issueStatuses.map((status) => <option key={status} value={status}>{pretty(status)}</option>)}
              </select>
            )}
            <div className="grid gap-3 sm:grid-cols-3">
              <Metric icon={<Users size={18} />} label="Members" value={community.memberCount} />
              <Metric icon={<CalendarDays size={18} />} label="Actions" value={community.activityCount} />
              <Metric icon={<CheckCircle2 size={18} />} label="Evidence" value={evidence.length} />
            </div>
          </section>
        )}

        {activeTab === "Members" && (
          <section className="space-y-3">
            {isOwner && (
              <div className="rounded-2xl border border-zinc-200 bg-white p-4 text-sm text-zinc-600 shadow-sm dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-300">
                <p className="font-bold text-zinc-950 dark:text-white">Owner controls</p>
                <p className="mt-1">Promote trusted members, assign moderators, or remove people from this issue community.</p>
              </div>
            )}
            {members.map((item) => (
              <div key={item.id} className="flex items-center gap-3 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                <img src={item.user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(item.user.displayName)}&background=111&color=fff`} alt="" className="h-11 w-11 rounded-full object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-black text-zinc-950 dark:text-white">{item.user.displayName}</p>
                  <p className="truncate text-xs text-zinc-500">@{item.user.username || "hivez"}</p>
                </div>
                {isOwner && item.role !== "owner" ? (
                  <div className="flex items-center gap-2">
                    <select value={item.role} onChange={(e) => updateCommunityMemberRole(item, e.target.value as CommunityMember["role"]).then(() => toast.success("Role updated")).catch((error) => toast.error(error.message))} className="h-9 rounded-full border border-zinc-200 bg-white px-3 text-xs font-bold capitalize dark:border-zinc-800 dark:bg-zinc-950 dark:text-white">
                      {["member", "moderator", "organizer"].map((role) => <option key={role} value={role}>{role}</option>)}
                    </select>
                    <button onClick={() => removeCommunityMember(community, item).then(() => toast.success("Member removed")).catch((error) => toast.error(error.message))} className="grid h-9 w-9 place-items-center rounded-full text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"><Trash2 size={15} /></button>
                  </div>
                ) : (
                  <span className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-bold capitalize text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300">{item.role}</span>
                )}
              </div>
            ))}
          </section>
        )}

        {activeTab === "Evidence" && (
          <section className="space-y-4">
            {canManage && (
              <div className="rounded-2xl border border-zinc-200 bg-white p-4 text-sm text-zinc-600 shadow-sm dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-300">
                <p className="font-bold text-zinc-950 dark:text-white">Evidence review</p>
                <p className="mt-1">Review submitted proof and mark it accepted or rejected so the community can track real progress.</p>
              </div>
            )}
            {isMember && activities.length > 0 && (
              <form onSubmit={handleSubmitEvidence} className="space-y-3 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
                <select value={evidenceActivityId} onChange={(e) => setPickedEvidenceActivityId(e.target.value || null)} className="h-12 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white">
                  {activities.map((activity) => <option key={activity.id} value={activity.id}>{activity.title}</option>)}
                </select>
                <div className="flex flex-wrap gap-2">
                  {(["AFTER", "BEFORE", "REPORT"] as const).map((kind) => (
                    <button key={kind} type="button" onClick={() => setEvidenceKind(kind)} className={`h-9 rounded-full px-3 text-xs font-bold transition ${evidenceKind === kind ? "bg-zinc-950 text-white dark:bg-white dark:text-black" : "border border-zinc-200 text-zinc-500 dark:border-zinc-800"}`}>
                      {kind === "AFTER" ? "After (result)" : kind === "BEFORE" ? "Before (original)" : "General report"}
                    </button>
                  ))}
                </div>
                <textarea value={evidenceDescription} onChange={(e) => setEvidenceDescription(e.target.value)} placeholder="Describe what was completed or verified" className="min-h-24 w-full rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
                {evidenceKind === "BEFORE" ? (
                  <>
                    <EvidenceMediaField
                      label="Before photo / video"
                      value={beforeEvidenceUrl}
                      onChange={setBeforeEvidenceUrl}
                      onUpload={(e) => handleEvidenceFile(e, "before")}
                      uploading={evidenceUploading}
                      hint="Original condition before any work started."
                    />
                    <EvidenceMediaField
                      label="After photo / video (optional)"
                      value={evidenceUrl}
                      onChange={setEvidenceUrl}
                      onUpload={(e) => handleEvidenceFile(e, "main")}
                      uploading={evidenceUploading}
                    />
                  </>
                ) : (
                  <EvidenceMediaField
                    label={evidenceKind === "AFTER" ? "Result photo / video" : "Optional photo / video"}
                    value={evidenceUrl}
                    onChange={setEvidenceUrl}
                    onUpload={(e) => handleEvidenceFile(e, "main")}
                    uploading={evidenceUploading}
                  />
                )}
                <button disabled={evidenceSubmitting || evidenceUploading} className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-zinc-950 px-5 text-sm font-bold text-white disabled:opacity-50 dark:bg-white dark:text-black">
                  {evidenceSubmitting && <Loader2 size={15} className="animate-spin" />}
                  {evidenceSubmitting ? "Submitting…" : "Submit evidence"}
                </button>
              </form>
            )}
            <EvidenceGallery
              items={evidence}
              activities={activities}
              canManage={canManage}
              onReview={(item, status) => reviewActivityEvidence(item, status).then(() => toast.success("Evidence updated")).catch((err) => toast.error(err.message))}
            />
          </section>
        )}

        {activeTab === "Verification" && (
          <VerificationPanel
            communityId={communityId}
            evidence={evidence}
            member={member}
            summary={summary}
            activities={activities}
          />
        )}
      </main>
    </div>
  );
}

function MessagePanel({ messages, canPost, value, onChange, onSubmit, mode }: { messages: CommunityMessage[]; canPost: boolean; value: string; onChange: (value: string) => void; onSubmit: (event: FormEvent) => void; mode: string }) {
  return (
    <section className="space-y-4">
      <div className="space-y-3">
        {messages.map((message) => (
          <div key={message.id} className="flex gap-3 rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-950">
            <img src={message.user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(message.user.displayName)}&background=111&color=fff`} alt="" className="h-10 w-10 rounded-full object-cover" />
            <div className="min-w-0">
              <p className="text-sm font-black text-zinc-950 dark:text-white">{message.user.displayName} <span className="font-semibold text-zinc-400">{timeText(message.createdAt)}</span></p>
              <p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6 text-zinc-700 dark:text-zinc-300">{message.text}</p>
            </div>
          </div>
        ))}
        {!messages.length && <div className="rounded-3xl border border-dashed border-zinc-300 p-8 text-center text-sm text-zinc-500 dark:border-zinc-800">No {mode.toLowerCase()} messages yet.</div>}
      </div>
      {canPost ? (
        <form onSubmit={onSubmit} className="mt-4 flex gap-2 rounded-full border border-zinc-200 bg-white p-2 shadow-lg dark:border-zinc-800 dark:bg-zinc-950">
          <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={`Write in ${mode.toLowerCase()}`} className="min-w-0 flex-1 bg-transparent px-4 text-sm outline-none dark:text-white" />
          <button disabled={!value.trim()} className="grid h-10 w-10 place-items-center rounded-full bg-zinc-950 text-white disabled:opacity-50 dark:bg-white dark:text-black"><Send size={17} /></button>
        </form>
      ) : (
        <p className="mt-4 rounded-3xl bg-zinc-100 p-4 text-center text-sm font-semibold text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300">Join the community to post.</p>
      )}
    </section>
  );
}

function toVerificationKind(kind: EvidenceTypeKey): "BEFORE" | "AFTER" | "REPORT" | "WITNESS" | "SUPPORTING" {
  switch (kind) {
    case "BEFORE":
    case "AFTER":
      return kind;
    case "WITNESS_CONFIRMATION":
      return "WITNESS";
    case "REPORT":
      return "REPORT";
    default:
      return "SUPPORTING";
  }
}

function ActivityCard({ activity, summary, canManage, isOwner, isCommunityMember, expanded, onToggleExpand }: { activity: VolunteerActivity; summary: VolunteerUserSummary | null; canManage: boolean; isOwner: boolean; isCommunityMember: boolean; expanded: boolean; onToggleExpand: () => void }) {
  const [participant, setParticipant] = useState<ActivityParticipant | null>(null);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(activity.title);
  const [description, setDescription] = useState(activity.description);
  const [location, setLocation] = useState(activity.location);
  const [startDate, setStartDate] = useState(activity.startDate);
  const [startTime, setStartTime] = useState(activity.startTime);
  const [limit, setLimit] = useState(String(activity.volunteerLimit || ""));
  const [roles, setRoles] = useState(activity.roles.join(", "));
  const joined = Boolean(participant);
  const cardFormConfig = getActionFormConfig(activity.actionType);
  const cardSummary = actionTypeSummary(activity);
  const showLimit = cardFormConfig.capacity && activity.volunteerLimit > 0;

  useEffect(() => {
    if (!summary) return;
    return listenActivityParticipant(activity.id, summary.uid, setParticipant);
  }, [activity.id, summary]);

  async function toggleJoin() {
    if (!summary || busy) return;
    setBusy(true);
    try {
      if (joined) await leaveActivity(activity, summary.uid);
      else await joinActivity(activity, summary, activity.roles[0] || "Volunteer");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not update activity");
    } finally {
      setBusy(false);
    }
  }

  async function saveActivity(event: FormEvent) {
    event.preventDefault();
    if (!title.trim() || busy) return;
    setBusy(true);
    try {
      await updateActivityDetails(activity.id, {
        title: title.trim(),
        description: description.trim(),
        location: location.trim(),
        meetingPoint: location.trim(),
        startDate,
        startTime,
        volunteerLimit: Number(limit) || 0,
        roles: roles.split(",").map((item) => item.trim()).filter(Boolean),
      });
      setEditing(false);
      toast.success("Action updated");
    } catch (error) {
      console.error(error);
      toast.error("Could not update action");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-950">
      {editing ? (
        <form onSubmit={saveActivity} className="space-y-3">
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm font-bold outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="min-h-24 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-2 text-sm outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
          <div className="grid gap-2 sm:grid-cols-2">
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="h-11 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="h-11 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
            <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Meeting point" className="h-11 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
            <input value={limit} onChange={(e) => setLimit(e.target.value)} placeholder="Volunteer limit" className="h-11 rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
          </div>
          <input value={roles} onChange={(e) => setRoles(e.target.value)} placeholder="Roles" className="h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm dark:border-zinc-800 dark:bg-zinc-900 dark:text-white" />
          <div className="flex gap-2">
            <button disabled={busy} className="h-9 rounded-full bg-zinc-950 px-4 text-xs font-bold text-white dark:bg-white dark:text-black">Save</button>
            <button type="button" onClick={() => setEditing(false)} className="h-9 rounded-full border border-zinc-200 px-4 text-xs font-bold dark:border-zinc-800">Cancel</button>
          </div>
        </form>
      ) : (
        <>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-black text-zinc-950 dark:text-white">{activity.title}</h3>
          {getActionType(activity.actionType) && (
            <p className="mt-0.5 text-xs font-bold text-zinc-500">
              <span>{getActionType(activity.actionType)!.emoji}</span> {getActionType(activity.actionType)!.label}
            </p>
          )}
          <p className="mt-1 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{activity.description}</p>
          {cardSummary.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {cardSummary.map((row) => (
                <span key={row.key} className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] font-semibold text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300">
                  {row.label}: {row.value}
                </span>
              ))}
            </div>
          )}
        </div>
        <span className="rounded-full bg-zinc-100 px-3 py-1 text-[11px] font-bold uppercase text-zinc-600 dark:bg-zinc-900 dark:text-zinc-300">{pretty(activity.status)}</span>
      </div>
      <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold text-zinc-500">
        {activity.startDate && (
          <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-3 py-1 dark:bg-zinc-900"><CalendarDays size={14} />{activity.startDate}</span>
        )}
        {activity.location && (
          <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-3 py-1 dark:bg-zinc-900"><MapPin size={14} />{activity.location}</span>
        )}
        <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-3 py-1 dark:bg-zinc-900"><Users size={14} />{activity.volunteerCount}{showLimit ? `/${activity.volunteerLimit}` : ""}</span>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button disabled={!isCommunityMember || busy} onClick={toggleJoin} className="h-10 rounded-full bg-zinc-950 px-5 text-sm font-bold text-white disabled:opacity-50 dark:bg-white dark:text-black">
          {joined ? "Leave action" : cardFormConfig.joinLabel}
        </button>
        {canManage ? (
          <>
            <select value={activity.status} onChange={(e) => updateActivityStatus(activity.id, e.target.value as VolunteerActivityStatus)} className="h-10 rounded-full border border-zinc-200 bg-white px-4 text-sm font-bold dark:border-zinc-800 dark:bg-zinc-950 dark:text-white">
              {activityStatuses.map((status) => <option key={status} value={status}>{pretty(status)}</option>)}
            </select>
            <select
              value={activity.progressState || "NOT_STARTED"}
              onChange={(e) => updateActionProgress({ activity, progressState: e.target.value as ActionProgressState, actor: summary! })}
              className="h-10 rounded-full border border-zinc-200 bg-white px-4 text-sm font-bold dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
            >
              {(["NOT_STARTED", "IN_PROGRESS", "WAITING_EXTERNAL", "WAITING_PROFESSIONAL", "AWAITING_EVIDENCE", "AWAITING_VERIFICATION", "COMPLETED"] as const).map((state) => (
                <option key={state} value={state}>{progressStateLabel(state)}</option>
              ))}
            </select>
          </>
        ) : (
          activity.progressState && (
            <span className="inline-flex h-10 items-center rounded-full bg-emerald-50 px-4 text-xs font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
              {progressStateLabel(activity.progressState)}
            </span>
          )
        )}
        <button onClick={onToggleExpand} className="h-10 rounded-full border border-zinc-200 px-4 text-sm font-bold dark:border-zinc-800">
          {expanded ? "Hide details" : "Manage"}
        </button>
        {canManage && <button onClick={() => setEditing(true)} className="h-10 rounded-full border border-zinc-200 px-4 text-sm font-bold dark:border-zinc-800">Edit</button>}
        {isOwner && activity.status !== "CANCELLED" && <button onClick={() => updateActivityStatus(activity.id, "CANCELLED").then(() => toast.success("Action cancelled"))} className="h-10 rounded-full border border-red-200 px-4 text-sm font-bold text-red-500 dark:border-red-950">Cancel action</button>}
      </div>
        </>
      )}
    </div>
  );
}

function EmptyBlock({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-zinc-300 p-8 text-center text-sm font-semibold text-zinc-500 dark:border-zinc-800">
      {text}
    </div>
  );
}

function Metric({ icon, label, value }: { icon: ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-3xl bg-zinc-50 p-4 dark:bg-zinc-900">
      <div className="text-zinc-500">{icon}</div>
      <p className="mt-3 text-2xl font-black text-zinc-950 dark:text-white">{value}</p>
      <p className="text-xs font-bold uppercase tracking-wide text-zinc-500">{label}</p>
    </div>
  );
}
function EvidenceMediaField({
  label,
  value,
  onChange,
  onUpload,
  uploading,
  hint,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  onUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
  uploading: boolean;
  hint?: string;
}) {
  const type = detectMediaType(value, undefined);
  return (
    <div className="space-y-1.5">
      <p className="text-[11px] font-black uppercase tracking-wide text-zinc-500">{label}</p>
      <div className="flex flex-wrap items-center gap-2">
        <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-full border border-dashed border-zinc-300 px-4 text-xs font-bold text-zinc-600 transition hover:border-zinc-400 dark:border-zinc-700 dark:text-zinc-300">
          {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
          {uploading ? "Uploading…" : "Upload image / video"}
          <input type="file" accept="image/*,video/*" className="hidden" onChange={onUpload} disabled={uploading} />
        </label>
        <span className="text-[11px] font-semibold text-zinc-400">or</span>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Paste a media URL"
          className="h-10 min-w-0 flex-1 rounded-full border border-zinc-200 bg-zinc-50 px-4 text-xs outline-none dark:border-zinc-800 dark:bg-zinc-900 dark:text-white"
        />
      </div>
      {hint && <p className="text-[10px] font-semibold text-zinc-400">{hint}</p>}
      {value && (
        <div className="relative w-full overflow-hidden rounded-2xl border border-zinc-200 dark:border-zinc-800">
          {type === "video" ? (
            <video src={value} muted playsInline preload="metadata" className="max-h-48 w-full object-cover" />
          ) : (
            <img src={value} alt="" className="max-h-48 w-full object-cover" />
          )}
          <button
            type="button"
            onClick={() => onChange("")}
            aria-label={`Remove ${label}`}
            className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-full bg-black/60 text-white backdrop-blur transition hover:bg-black/80"
          >
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
